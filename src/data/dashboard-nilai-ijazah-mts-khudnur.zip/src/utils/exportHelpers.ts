import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Student, Subject, FormulaConfig, SchoolInfo } from '../types';
import { getStudentStats, getSubjectStatsList } from './calculations';

/**
 * Generates and downloads a complete Excel Ledger for MTs KHUDNUR
 */
export const exportToExcel = (
  students: Student[],
  subjects: Subject[],
  formula: FormulaConfig,
  schoolInfo: SchoolInfo
) => {
  const wb = XLSX.utils.book_new();

  // ----- SHEET 1: LEDGER SKOR INDIVIDU -----
  // Prepare row matrix
  const matrixData: any[][] = [
    [schoolInfo.name.toUpperCase()],
    [`DAFTAR NILAI IJAZAH - TAHUN PELAJARAN 2025/2026`],
    [`Alamat: ${schoolInfo.address}, ${schoolInfo.subdistrict}, ${schoolInfo.city}`],
    [], // empty spacer
  ];

  // Subject codes subheaders
  const headers = [
    "No",
    "NIS",
    "NISN",
    "Nama Siswa",
    "L/P",
    ...subjects.map(s => `${s.name} (Rapor)`),
    ...subjects.map(s => `${s.name} (UM)`),
    ...subjects.map(s => `${s.name} (Akhir)`),
    "Rerata Rapor (Sem 1-5)",
    "Rerata Ujian Madrasah",
    "Rangkuman Akhir Ijazah",
    "Keterangan KKM"
  ];
  matrixData.push(headers);

  // Rows of student records
  students.forEach((student, index) => {
    const stats = getStudentStats(student, subjects, formula);
    
    const row = [
      index + 1,
      student.nis,
      student.nisn,
      student.nama,
      student.gender,
      // 1. Rapor Averages for each subject
      ...subjects.map(s => student.grades[s.id]?.rataRapor ?? 0),
      // 2. UM grades for each subject
      ...subjects.map(s => student.grades[s.id]?.um ?? 0),
      // 3. Final weighted grades for each subject
      ...subjects.map(s => student.grades[s.id]?.nilaiIjazah ?? 0),
      stats.averageRapor,
      stats.averageUM,
      stats.averageIjazah,
      stats.isPassed ? "LULUS" : `REMEDIAL (${stats.failedSubjectsCount} Mapel)`
    ];
    matrixData.push(row);
  });

  const wsLedger = XLSX.utils.aoa_to_sheet(matrixData);

  // Set nice design widths for key columns
  const colWidths = [
    { wch: 5 },  // No
    { wch: 12 }, // NIS
    { wch: 14 }, // NISN
    { wch: 25 }, // Nama
    { wch: 6 },  // L/P
  ];
  // populate default widths for subjects
  for (let i = 0; i < subjects.length * 3; i++) {
    colWidths.push({ wch: 12 });
  }
  colWidths.push({ wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 16 });
  wsLedger['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(wb, wsLedger, "Ledger Nilai Ijazah");

  // ----- SHEET 2: RINGKASAN & STATISTIK -----
  const statMatrix: any[][] = [
    [`RINGKASAN STATISTIK MATA PELAJARAN - ${schoolInfo.name}`],
    [`Kriteria Ketuntasan Minimal (KKM): ${formula.kkm}`],
    [],
    ["No", "Kode Mapel", "Nama Mata Pelajaran", "Rata-rata Rapor", "Rata-rata UM", "Rata-rata Nilai Ijazah", "Nilai Tertinggi", "Nilai Terendah", "Persentase Kelulusan"]
  ];

  const subjectStats = getSubjectStatsList(students, subjects, formula);
  subjectStats.forEach((stat, index) => {
    statMatrix.push([
      index + 1,
      stat.subjectCode,
      stat.subjectName,
      stat.averageRapor,
      stat.averageUM,
      stat.averageIjazah,
      stat.highestIjazah,
      stat.lowestIjazah,
      `${stat.passPercentage}%`
    ]);
  });

  const wsStats = XLSX.utils.aoa_to_sheet(statMatrix);
  wsStats['!cols'] = [
    { wch: 5 },  // No
    { wch: 10 }, // Kode
    { wch: 30 }, // Nama
    { wch: 16 }, // Rata Rapor
    { wch: 16 }, // Rata UM
    { wch: 20 }, // Rata Ijazah
    { wch: 16 }, // Max
    { wch: 16 }, // Min
    { wch: 18 }  // Pass
  ];

  XLSX.utils.book_append_sheet(wb, wsStats, "Statistik Mapel");

  // Write and Save
  XLSX.writeFile(wb, `Ledger_Nilai_Ijazah_${schoolInfo.name.replace(/\s+/g, '_')}_2026.xlsx`);
};

const spellIntegerID = (val: number): string => {
  const words = ["Nol", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas"];
  if (val <= 11) return words[val];
  if (val < 20) {
    return words[val - 10] + " Belas";
  }
  if (val < 100) {
    const tens = Math.floor(val / 10);
    const ones = val % 10;
    return words[tens] + " Puluh" + (ones > 0 ? " " + words[ones] : "");
  }
  if (val === 100) return "Seratus";
  return String(val);
};

const spellDigitsID = (str: string): string => {
  const words: Record<string, string> = {
    '0': 'Nol', '1': 'Satu', '2': 'Dua', '3': 'Tiga', '4': 'Empat',
    '5': 'Lima', '6': 'Enam', '7': 'Tujuh', '8': 'Delapan', '9': 'Sembilan'
  };
  return str.split('').map(char => words[char] || char).join(' ');
};

export const spellNumberID = (num: number, isAverage = false): string => {
  if (isNaN(num)) return '-';
  if (!isAverage) {
    const formatted = num % 1 === 0 ? num.toFixed(0) : num.toFixed(1);
    const parts = formatted.split('.');
    const intSpelled = spellDigitsID(parts[0]);
    if (parts.length > 1) {
      return `${intSpelled} Koma ${spellDigitsID(parts[1])}`;
    }
    return intSpelled;
  } else {
    const formatted = num.toFixed(2);
    const parts = formatted.split('.');
    const integerVal = parseInt(parts[0], 10);
    const intSpelled = spellIntegerID(integerVal);
    const decSpelled = spellDigitsID(parts[1]);
    return `${intSpelled} Koma ${decSpelled}`;
  }
};

const drawKemenagLogo = (doc: jsPDF, x: number, y: number, size = 18) => {
  doc.setLineWidth(0.3);
  doc.setFillColor(16, 124, 65); // Kemenag Green
  
  const r = size / 2;
  const cx = x + r;
  const cy = y + r;
  
  doc.ellipse(cx, cy, r, r, 'F');
  
  doc.setFillColor(234, 182, 10); // Golden yellow
  doc.ellipse(cx, cy, r - 1.2, r - 1.2, 'F');
  
  doc.setFillColor(16, 124, 65); // Kemenag Green
  doc.ellipse(cx, cy, r - 2.4, r - 2.4, 'F');
  
  doc.setFillColor(234, 182, 10);
  doc.rect(cx - 3, cy - 2, 6, 4.5, 'F');
  
  // book pages
  doc.setFillColor(255, 255, 255);
  doc.rect(cx - 2, cy - 1, 4, 0.8, 'F');

  // reset to default colors
  doc.setFillColor(0, 0, 0);
  doc.setDrawColor(0, 0, 0);
};

const drawQRCode = (doc: jsPDF, x: number, y: number, size = 26) => {
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.1);
  doc.rect(x - 1, y - 1, size + 2, size + 2);

  doc.setFillColor(0, 0, 0);

  const drawFinder = (fx: number, fy: number) => {
    doc.rect(fx, fy, 7, 7, 'F');
    doc.setFillColor(255, 255, 255);
    doc.rect(fx + 1, fy + 1, 5, 5, 'F');
    doc.setFillColor(0, 0, 0);
    doc.rect(fx + 2, fy + 2, 3, 3, 'F');
  };

  drawFinder(x, y);
  drawFinder(x + size - 7, y);
  drawFinder(x, y + size - 7);

  doc.setFillColor(0, 0, 0);
  
  const steps = 15;
  const pixelSize = size / steps;
  for (let row = 0; row < steps; row++) {
    for (let col = 0; col < steps; col++) {
      const inTopLeft = row < 7 && col < 7;
      const inTopRight = row < 7 && col >= steps - 7;
      const inBottomLeft = row >= steps - 7 && col < 7;
      
      if (!inTopLeft && !inTopRight && !inBottomLeft) {
        const isBlack = ((row * 7 + col * 13) % 5 === 0) || ((row + col) % 3 === 0);
        if (isBlack) {
          doc.rect(x + col * pixelSize, y + row * pixelSize, pixelSize, pixelSize, 'F');
        }
      }
    }
  }

  // Draw tiny crest in center
  const centerSize = 6;
  const cx = x + (size - centerSize) / 2;
  const cy = y + (size - centerSize) / 2;
  
  doc.setFillColor(255, 255, 255);
  doc.rect(cx - 0.5, cy - 0.5, centerSize + 1, centerSize + 1, 'F');
  
  doc.setFillColor(16, 124, 65);
  doc.rect(cx, cy, centerSize, centerSize, 'F');
  doc.setFillColor(234, 182, 10);
  doc.rect(cx + 1, cy + 1, centerSize - 2, centerSize - 2, 'F');
  doc.setFillColor(16, 124, 65);
  doc.rect(cx + 2, cy + 2, centerSize - 4, centerSize - 4, 'F');

  // reset to default colors
  doc.setFillColor(0, 0, 0);
  doc.setDrawColor(0, 0, 0);
};

const drawFotoBox = (doc: jsPDF, x: number, y: number, w = 24, h = 32) => {
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.3);
  doc.rect(x, y, w, h);
  
  doc.setFont('times', 'normal');
  doc.setFontSize(9);
  doc.text("Foto", x + w/2, y + h/2 - 2, { align: 'center' });
  doc.text("3x4", x + w/2, y + h/2 + 3, { align: 'center' });
};

const drawWatermark = (doc: jsPDF) => {
  doc.setDrawColor(240, 248, 240);
  doc.setFillColor(242, 249, 242);
  doc.setLineWidth(0.5);
  
  doc.ellipse(105, 148, 45, 45, 'F');
  
  doc.setDrawColor(230, 242, 230);
  doc.ellipse(105, 148, 40, 40, 'D');
  doc.ellipse(105, 148, 30, 30, 'D');
  
  doc.setFont('times', 'bold');
  doc.setFontSize(28);
  doc.setTextColor(230, 240, 230);
  doc.text("IKHLAS BERAMAL", 105, 151, { align: 'center' });

  // reset to default colors/draw styles
  doc.setTextColor(0, 0, 0);
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(0, 0, 0);
};

const getLevelTitle = (schoolName: string): string => {
  const upper = schoolName.toUpperCase();
  if (upper.includes("MA ") || upper.includes("MAS ") || upper.includes("MAN ") || upper.startsWith("MA") || upper.startsWith("MAS")) {
    return "MADRASAH ALIYAH";
  }
  return "MADRASAH TSANAWIYAH";
};

const getSklNumber = (student: Student, schoolInfo: SchoolInfo): string => {
  if (student.sklNumber && student.sklNumber.trim() !== '') {
    return student.sklNumber;
  }
  
  if (schoolInfo.sklFormat && schoolInfo.sklFormat.trim() !== '') {
    let fmt = schoolInfo.sklFormat;
    fmt = fmt.replace(/\[NIS\]/g, student.nis);
    fmt = fmt.replace(/\[NISN\]/g, student.nisn || '');
    fmt = fmt.replace(/\[NAMA\]/g, student.nama);
    return fmt;
  }

  const initials = schoolInfo.name
    .replace(/KEMENTERIAN AGAMA|REPUBLIK INDONESIA/gi, "")
    .trim()
    .split(/\s+/)
    .map(p => p[0])
    .join("")
    .toUpperCase();
  const code = initials.length >= 2 ? initials : "MTS.K";
  return `084.08/${code}/PP.00.6/06/2026`;
};

const isIslamicSubject = (sub: Subject): boolean => {
  const id = sub.id.toLowerCase();
  const name = sub.name.toLowerCase();
  return id.includes('qur') || id.includes('akidah') || id.includes('fikih') || id.includes('ski') ||
         name.includes("qur'an") || name.includes("akidah") || name.includes("fikih") || name.includes("sejarah kebudayaan islam") || name.includes("sejarah kebudayaan") || name.includes("alquran");
};

const getCityAndProvinceShort = (info: SchoolInfo): string => {
  const city = info.city || '';
  const prov = info.province || '';
  return `${city} - ${prov}`;
};

const drawLabeledUnderlinedRow = (doc: jsPDF, label: string, value: string, y: number) => {
  doc.setFont('times', 'normal');
  doc.setFontSize(10.5);
  doc.text(label, 20, y);
  doc.text(":", 72, y);
  
  doc.setFont('times', 'bold');
  doc.text(value, 75, y);
  
  doc.setLineWidth(0.2);
  doc.setDrawColor(180, 180, 180);
  doc.line(75, y + 1, 185, y + 1);
};

const drawTranscriptBiodataRow = (doc: jsPDF, label: string, value: string, y: number) => {
  doc.setFont('times', 'normal');
  doc.setFontSize(9.5);
  doc.text(label, 14, y);
  doc.text(":", 70, y);
  
  doc.setFont('times', 'bold');
  doc.text(value, 72, y);
  
  doc.setLineWidth(0.15);
  doc.setDrawColor(180, 180, 180);
  doc.line(72, y + 1, 196, y + 1);
};

export const exportIndividualPDF = (
  student: Student,
  subjects: Subject[],
  formula: FormulaConfig,
  schoolInfo: SchoolInfo
) => {
  const doc = new jsPDF();
  const stats = getStudentStats(student, subjects, formula);

  // ==========================================
  // PAGE 1: SURAT KETERANGAN LULUS
  // ==========================================
  drawWatermark(doc);
  if (schoolInfo.logoType === 'custom' && schoolInfo.customLogo) {
    try {
      doc.addImage(schoolInfo.customLogo, 'PNG', 16, 12, 22, 22);
    } catch (e) {
      console.error("Gagal menggambar logo kustom di halaman 1:", e);
      drawKemenagLogo(doc, 16, 14, 20);
    }
  } else {
    drawKemenagLogo(doc, 16, 14, 20);
  }

  doc.setFont('times', 'normal');
  doc.setFontSize(11);
  doc.text("KEMENTERIAN AGAMA REPUBLIK INDONESIA", 105, 16, { align: 'center' });

  doc.setFont('times', 'bold');
  doc.setFontSize(14);
  doc.text(schoolInfo.name.toUpperCase(), 105, 22, { align: 'center' });

  doc.setFont('times', 'italic');
  doc.setFontSize(9.5);
  doc.text(schoolInfo.address.toUpperCase(), 105, 27, { align: 'center' });

  doc.setFont('times', 'italic');
  doc.setFontSize(9);
  doc.text(`Kecamatan ${schoolInfo.subdistrict}, ${getCityAndProvinceShort(schoolInfo)}`, 105, 32, { align: 'center' });

  // Double horizontal borders
  doc.setLineWidth(1.2);
  doc.setDrawColor(0, 0, 0);
  doc.line(14, 36, 196, 36);
  doc.setLineWidth(0.4);
  doc.line(14, 37.2, 196, 37.2);

  // Title of page 1
  let currentY = 46;
  doc.setFont('times', 'bold');
  doc.setFontSize(13);
  doc.text("SURAT KETERANGAN LULUS", 105, currentY, { align: 'center' });
  currentY += 5;
  doc.text(`TAHUN AJARAN 2025/2026`, 105, currentY, { align: 'center' });
  currentY += 5;
  doc.setFont('times', 'normal');
  doc.setFontSize(10.5);
  doc.text(`Nomor: ${getSklNumber(student, schoolInfo)}`, 105, currentY, { align: 'center' });
  currentY += 12;

  // Introduction
  doc.text("Yang bertanda tangan di bawah ini menerangkan bahwa:", 14, currentY);
  currentY += 8;

  // Student details with lines
  drawLabeledUnderlinedRow(doc, "nama", student.nama.toUpperCase(), currentY);
  currentY += 7;
  drawLabeledUnderlinedRow(doc, "tempat dan tanggal lahir", `${student.tempatLahir.toUpperCase()}, ${formatDateID(student.tanggalLahir)}`, currentY);
  currentY += 7;
  drawLabeledUnderlinedRow(doc, "nomor induk siswa nasional", student.nisn || "-", currentY);
  currentY += 7;
  drawLabeledUnderlinedRow(doc, "nomor peserta ujian madrasah", `26-10-23-3-0530-${student.nis.slice(-4) || '0001'}`, currentY);
  currentY += 7;
  drawLabeledUnderlinedRow(doc, "satuan pendidikan", schoolInfo.name.toUpperCase(), currentY);
  currentY += 7;
  drawLabeledUnderlinedRow(doc, "nomor pokok sekolah nasional", schoolInfo.npsn || "-", currentY);
  currentY += 12;

  // Statement paragraph
  doc.setFont('times', 'normal');
  doc.setFontSize(10.5);
  
  const textParagraph = `dinyatakan LULUS berdasarkan surat keputusan kepala ${schoolInfo.name.toUpperCase()} Nomor ${getSklNumber(student, schoolInfo)} tanggal 2 Juni 2026 setelah memenuhi seluruh kriteria sesuai dengan peraturan perundang-undangan.`;

  const splitLines = doc.splitTextToSize(textParagraph, 178);
  let lineY = currentY;
  splitLines.forEach((line: string) => {
    doc.text(line, 14, lineY);
    lineY += 5.5;
  });
  currentY = lineY + 4;

  doc.text("Demikian surat keterangan ini dibuat untuk digunakan sebagaimana mestinya.", 14, currentY);

  // Signatures of page 1 at bottom
  const bottomY = 162;
  drawQRCode(doc, 20, bottomY, 26);
  drawFotoBox(doc, 75, bottomY, 24, 32);

  const signatureX = 125;
  doc.setFont('times', 'normal');
  doc.setFontSize(10.5);
  doc.text(`${schoolInfo.city.replace('Kabupaten ', '').replace('Kota ', '')}, 2 Juni 2026`, signatureX, bottomY);
  doc.text("Kepala Madrasah,", signatureX, bottomY + 5);

  doc.setFont('times', 'bold');
  doc.text(schoolInfo.headmaster, signatureX, bottomY + 27);
  doc.setLineWidth(0.25);
  doc.setDrawColor(0, 0, 0);
  doc.line(signatureX, bottomY + 28, signatureX + 58, bottomY + 28);
  doc.setFont('times', 'normal');
  doc.text(`NIP. ${schoolInfo.headmasterNip || '-'}`, signatureX, bottomY + 32);

  // ==========================================
  // PAGE 2: TRANSKRIP NILAI
  // ==========================================
  doc.addPage();
  drawWatermark(doc);
  if (schoolInfo.logoType === 'custom' && schoolInfo.customLogo) {
    try {
      doc.addImage(schoolInfo.customLogo, 'PNG', 16, 12, 22, 22);
    } catch (e) {
      console.error("Gagal menggambar logo kustom di halaman 2:", e);
      drawKemenagLogo(doc, 16, 14, 20);
    }
  } else {
    drawKemenagLogo(doc, 16, 14, 20);
  }

  doc.setFont('times', 'normal');
  doc.setFontSize(11);
  doc.text("KEMENTERIAN AGAMA REPUBLIK INDONESIA", 105, 16, { align: 'center' });

  doc.setFont('times', 'bold');
  doc.setFontSize(14);
  doc.text(schoolInfo.name.toUpperCase(), 105, 22, { align: 'center' });

  doc.setFont('times', 'italic');
  doc.setFontSize(9.5);
  doc.text(schoolInfo.address.toUpperCase(), 105, 27, { align: 'center' });

  doc.setFont('times', 'italic');
  doc.setFontSize(9);
  doc.text(`Kecamatan ${schoolInfo.subdistrict}, ${getCityAndProvinceShort(schoolInfo)}`, 105, 32, { align: 'center' });

  // Double horizontal borders
  doc.setLineWidth(1.2);
  doc.setDrawColor(0, 0, 0);
  doc.line(14, 36, 196, 36);
  doc.setLineWidth(0.4);
  doc.line(14, 37.2, 196, 37.2);

  // Page 2 Title
  doc.setFont('times', 'bold');
  doc.setFontSize(12.5);
  doc.text("TRANSKRIP NILAI", 105, 45, { align: 'center' });
  doc.text(`${getLevelTitle(schoolInfo.name)} PEMINATAN KEAGAMAAN`, 105, 50, { align: 'center' });
  doc.setFontSize(11);
  doc.text("TAHUN AJARAN 2025/2026", 105, 55, { align: 'center' });

  // Page 2 Metadata
  let metaY = 62;
  drawTranscriptBiodataRow(doc, "Satuan Pendidikan", schoolInfo.name.toUpperCase(), metaY);
  metaY += 5;
  drawTranscriptBiodataRow(doc, "Nomor Pokok Sekolah Nasional", schoolInfo.npsn || "-", metaY);
  metaY += 5;
  drawTranscriptBiodataRow(doc, "Nama Lengkap", student.nama.toUpperCase(), metaY);
  metaY += 5;
  drawTranscriptBiodataRow(doc, "Tempat dan Tanggal Lahir", `${student.tempatLahir.toUpperCase()}, ${formatDateID(student.tanggalLahir)}`, metaY);
  metaY += 5;
  drawTranscriptBiodataRow(doc, "Nomor Induk Siswa Nasional", student.nisn || "-", metaY);
  metaY += 5;
  drawTranscriptBiodataRow(doc, "Nomor SKL", getSklNumber(student, schoolInfo), metaY);
  metaY += 5;
  drawTranscriptBiodataRow(doc, "Tanggal Kelulusan", "2 Juni 2026", metaY);

  // Build rows array for grading table
  const tableRows: any[] = [];
  
  // 2a. KELOMPOK A
  tableRows.push([
    { content: "Kelompok A", colSpan: 4, styles: { fontStyle: 'bold', fillColor: [245, 245, 245], fontSize: 8.5 } }
  ]);
  
  const compASubjects = subjects.filter(s => s.category === 'Kelompok A (Umum)');
  const islamicSubs = compASubjects.filter(isIslamicSubject);
  const generalSubs = compASubjects.filter(s => !isIslamicSubject(s));
  
  let orderNoA = 1;
  if (islamicSubs.length > 0) {
    tableRows.push([
      "1",
      { content: "Pendidikan Agama Islam", styles: { fontStyle: 'bold' } },
      "",
      ""
    ]);
    const alphabet = ["A", "B", "C", "D", "E", "F", "G"];
    islamicSubs.forEach((sub, idx) => {
      const g = student.grades[sub.id]?.nilaiIjazah ?? 0;
      const char = alphabet[idx] || String(idx + 1);
      tableRows.push([
        "",
        `     ${char}. ${sub.name}`,
        g.toFixed(0),
        spellNumberID(g, false)
      ]);
    });
    orderNoA = 2;
  }
  
  generalSubs.forEach((sub) => {
    const g = student.grades[sub.id]?.nilaiIjazah ?? 0;
    tableRows.push([
      String(orderNoA++),
      sub.name,
      g.toFixed(0),
      spellNumberID(g, false)
    ]);
  });
  
  // 2b. KELOMPOK B
  tableRows.push([
    { content: "Kelompok B", colSpan: 4, styles: { fontStyle: 'bold', fillColor: [245, 245, 245], fontSize: 8.5 } }
  ]);
  
  const compBSubjects = subjects.filter(s => s.category === 'Kelompok B (Umum)');
  const mulokSubjects = subjects.filter(s => s.category === 'Muatan Lokal');
  
  let orderNoB = 1;
  compBSubjects.forEach((sub) => {
    const g = student.grades[sub.id]?.nilaiIjazah ?? 0;
    tableRows.push([
      String(orderNoB++),
      sub.name,
      g.toFixed(0),
      spellNumberID(g, false)
    ]);
  });
  
  if (mulokSubjects.length > 0) {
    tableRows.push([
      String(orderNoB++),
      { content: "Muatan Lokal", styles: { fontStyle: 'bold' } },
      "",
      ""
    ]);
    const alphabet = ["A", "B", "C", "D", "E", "F", "G"];
    mulokSubjects.forEach((sub, idx) => {
      const g = student.grades[sub.id]?.nilaiIjazah ?? 0;
      const char = alphabet[idx] || String(idx + 1);
      tableRows.push([
        "",
        `     ${char}. ${sub.name}`,
        g.toFixed(0),
        spellNumberID(g, false)
      ]);
    });
  }

  // RATA-RATA row
  tableRows.push([
    { content: "Rata-Rata", colSpan: 2, styles: { fontStyle: 'bold', halign: 'center', fillColor: [245, 245, 245] } },
    { content: stats.averageIjazah.toFixed(2).replace('.', ','), styles: { fontStyle: 'bold', halign: 'center', fillColor: [245, 245, 245] } },
    { content: spellNumberID(stats.averageIjazah, true), styles: { fontStyle: 'bold', fillColor: [245, 245, 245] } }
  ]);

  // Draw autotable on Page 2
  autoTable(doc, {
    startY: 102,
    head: [
      [
        { content: 'No', rowSpan: 2, styles: { halign: 'center', valign: 'middle', fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', lineWidth: 0.2, fontSize: 8.5 } },
         { content: 'Mata Pelajaran', rowSpan: 2, styles: { halign: 'center', valign: 'middle', fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', lineWidth: 0.2, fontSize: 8.5 } },
         { content: 'Nilai', colSpan: 2, styles: { halign: 'center', valign: 'middle', fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', lineWidth: 0.2, fontSize: 8.5 } }
       ],
       [
         { content: 'Angka', styles: { halign: 'center', fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', lineWidth: 0.2, fontSize: 8.5 } },
         { content: 'Huruf', styles: { halign: 'center', fillColor: [255, 255, 255], textColor: [0, 0, 0], fontStyle: 'bold', lineWidth: 0.2, fontSize: 8.5 } }
       ]
    ],
    body: tableRows,
    theme: 'grid',
    styles: { font: 'times', fontSize: 8, cellPadding: 1.5, textColor: [0, 0, 0], lineColor: [0, 0, 0], lineWidth: 0.15 },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 80 },
      2: { cellWidth: 20, halign: 'center' },
      3: { cellWidth: 70 }
    },
    didDrawPage: (data: any) => {
      currentY = data.cursor.y + 10;
    }
  });

  // Align signatures/QR of Page 2
  const bottomTransY = Math.max(currentY, 232);
  drawQRCode(doc, 20, bottomTransY, 26);

  doc.setFont('times', 'normal');
  doc.setFontSize(10);
  doc.text(`${schoolInfo.city.replace('Kabupaten ', '').replace('Kota ', '')}, 2 Juni 2026`, signatureX, bottomTransY);
  doc.text("Kepala Madrasah,", signatureX, bottomTransY + 5);

  doc.setFont('times', 'bold');
  doc.text(schoolInfo.headmaster, signatureX, bottomTransY + 27);
  doc.setLineWidth(0.25);
  doc.setDrawColor(0, 0, 0);
  doc.line(signatureX, bottomTransY + 28, signatureX + 58, bottomTransY + 28);
  doc.setFont('times', 'normal');
  doc.text(`NIP. ${schoolInfo.headmasterNip || '-'}`, signatureX, bottomTransY + 32);

  doc.save(`SKL_${student.nama.replace(/\s+/g, '_')}_${student.nis}.pdf`);
};

/**
 * Basic mapper to convert YYYY-MM-DD into Indonesian formatted date: e.g. "12 April 2011"
 */
const formatDateID = (dateStr: string): string => {
  if (!dateStr) return '';
  const months = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  try {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const day = parseInt(parts[2], 10);
      const monthIdx = parseInt(parts[1], 10) - 1;
      const year = parts[0];
      return `${day} ${months[monthIdx]} ${year}`;
    }
  } catch (e) {
    // return raw
  }
  return dateStr;
};

/**
 * Generates and downloads the XLSX template for adding new students
 */
export const downloadStudentTemplate = () => {
  const wb = XLSX.utils.book_new();
  
  const headers = ["No", "NIS", "NISN", "Nama Siswa", "L/P", "Kelas"];
  const sampleData = [
    [1, "202307006", "0105432101", "Budi Santoso", "L", "9-A"],
    [2, "202307007", "0105432102", "Susi Susanti", "P", "9-B"],
    [3, "202307008", "0105432103", "Rian Hidayat", "L", "9-A"],
    [4, "202307009", "0105432104", "Dewi Lestari", "P", "9-C"],
  ];
  
  const matrix = [
    ["TEMPLATE TAMBAH SISWA BARU - MTs KHUDNUR"],
    ["Petunjuk: Isi data siswa baru mulai dari baris ke-4. Kolom L/P diisi L (Laki-laki) atau P (Perempuan)."],
    ["Gunakan file ini untuk menambahkan siswa secara massal lalu unggah ke aplikasi."],
    headers,
    ...sampleData
  ];
  
  const ws = XLSX.utils.aoa_to_sheet(matrix);
  
  ws['!cols'] = [
    { wch: 6 },  // No
    { wch: 15 }, // NIS
    { wch: 15 }, // NISN
    { wch: 25 }, // Nama Siswa
    { wch: 8 },  // L/P
    { wch: 10 }  // Kelas
  ];
  
  XLSX.utils.book_append_sheet(wb, ws, "Siswa Baru");
  XLSX.writeFile(wb, "Template_Tambah_Siswa_Baru.xlsx");
};

/**
 * Generates and downloads the XLSX template for uploading grades
 */
export const downloadGradesTemplate = (students: Student[], subjects: Subject[]) => {
  const wb = XLSX.utils.book_new();
  
  const headers = [
    "No",
    "NIS",
    "NISN",
    "Nama Siswa",
    "L/P",
    "Kelas",
    ...subjects.flatMap(s => [`${s.name} (Rapor)`, `${s.name} (UM)`])
  ];
  
  const rowsData: any[][] = [];
  
  if (students && students.length > 0) {
    students.forEach((std, idx) => {
      const studentGradesRow: any[] = [
        idx + 1,
        std.nis,
        std.nisn,
        std.nama,
        std.gender,
        std.kelas
      ];
      
      subjects.forEach(sub => {
        const studentGrades = std.grades[sub.id] || { rataRapor: 80, um: 80 };
        studentGradesRow.push(studentGrades.rataRapor || 0);
        studentGradesRow.push(studentGrades.um || 50); // Using 50 or other standard minimum or current
      });
      
      rowsData.push(studentGradesRow);
    });
  } else {
    // Fallback sample data row if no students are loaded yet
    const sampleRow = [
      1,
      "202307001",
      "0102345678",
      "Ahmad Fauzi",
      "L",
      "9-A"
    ];
    subjects.forEach(() => {
      sampleRow.push(80, 85);
    });
    rowsData.push(sampleRow);
  }
  
  const matrix = [
    ["TEMPLATE UNGGAH NILAI SISWA - MTs KHUDNUR"],
    ["Petunjuk: Kolom (Rapor) diisi rata-rata nilai semester 1-5 (skala 0-100). Kolom (UM) diisi nilai Ujian Madrasah."],
    ["Tabel ini otomatis menyertakan seluruh daftar siswa yang aktif saat ini. Silakan ubah nilainya lalu simpan & unggah."],
    headers,
    ...rowsData
  ];
  
  const ws = XLSX.utils.aoa_to_sheet(matrix);
  
  const colWidths = [
    { wch: 6 },  // No
    { wch: 15 }, // NIS
    { wch: 15 }, // NISN
    { wch: 25 }, // Nama Siswa
    { wch: 8 },  // L/P
    { wch: 10 }  // Kelas
  ];
  subjects.forEach(() => {
    colWidths.push({ wch: 22 }, { wch: 22 });
  });
  ws['!cols'] = colWidths;
  
  XLSX.utils.book_append_sheet(wb, ws, "Unggah Nilai");
  XLSX.writeFile(wb, "Template_Unggah_Nilai.xlsx");
};

